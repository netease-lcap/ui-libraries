/// <reference types="@nasl/types" />
/// <reference types="@nasl/types" />
/// <reference types="@nasl/types" />
/// <reference types="@nasl/types" />
declare namespace nasl.ui {
    class Breadcrumb extends ViewComponent {
        constructor(options?: Partial<BreadcrumbOptions>);
    }
    class BreadcrumbOptions extends ViewComponentOptions {
        separator: nasl.core.String;
        slotDefault: () => Array<BreadcrumbItem>;
    }
    class BreadcrumbItem extends ViewComponent {
        constructor(options?: Partial<BreadcrumbItemOptions>);
    }
    class BreadcrumbItemOptions extends ViewComponentOptions {
        href: nasl.core.String;
        onClick: (event: {
            altKey: nasl.core.Boolean;
            button: nasl.core.Integer;
            clientX: nasl.core.Integer;
            clientY: nasl.core.Integer;
            ctrlKey: nasl.core.Boolean;
            metaKey: nasl.core.Boolean;
            movementX: nasl.core.Integer;
            movementY: nasl.core.Integer;
            offsetX: nasl.core.Integer;
            offsetY: nasl.core.Integer;
            pageX: nasl.core.Integer;
            pageY: nasl.core.Integer;
            screenX: nasl.core.Integer;
            screenY: nasl.core.Integer;
            which: nasl.core.Integer;
        }) => any;
        slotDefault: () => Array<ViewComponent>;
    }
}
declare namespace nasl.ui {
    class Button extends ViewComponent {
        constructor(options?: Partial<ButtonOptions>);
    }
    class ButtonOptions extends ViewComponentOptions {
        children: nasl.core.String;
        type: 'primary' | 'dashed' | 'default' | 'text' | 'link';
        icon: nasl.core.String;
        disabled: nasl.core.Boolean;
        private loading;
        size: 'large' | 'medium' | 'small';
        shape: 'default' | 'round' | 'circle';
        slotDefault: () => Array<ViewComponent>;
        onClick: (event: {
            altKey: nasl.core.Boolean;
            button: nasl.core.Integer;
            clientX: nasl.core.Integer;
            clientY: nasl.core.Integer;
            ctrlKey: nasl.core.Boolean;
            metaKey: nasl.core.Boolean;
            movementX: nasl.core.Integer;
            movementY: nasl.core.Integer;
            offsetX: nasl.core.Integer;
            offsetY: nasl.core.Integer;
            pageX: nasl.core.Integer;
            pageY: nasl.core.Integer;
            screenX: nasl.core.Integer;
            screenY: nasl.core.Integer;
            which: nasl.core.Integer;
        }) => any;
        onDoubleClick: (event: {
            altKey: nasl.core.Boolean;
            button: nasl.core.Integer;
            clientX: nasl.core.Integer;
            clientY: nasl.core.Integer;
            ctrlKey: nasl.core.Boolean;
            metaKey: nasl.core.Boolean;
            movementX: nasl.core.Integer;
            movementY: nasl.core.Integer;
            offsetX: nasl.core.Integer;
            offsetY: nasl.core.Integer;
            pageX: nasl.core.Integer;
            pageY: nasl.core.Integer;
            screenX: nasl.core.Integer;
            screenY: nasl.core.Integer;
            which: nasl.core.Integer;
        }) => any;
        onContextMenu: (event: {
            altKey: nasl.core.Boolean;
            button: nasl.core.Integer;
            clientX: nasl.core.Integer;
            clientY: nasl.core.Integer;
            ctrlKey: nasl.core.Boolean;
            metaKey: nasl.core.Boolean;
            movementX: nasl.core.Integer;
            movementY: nasl.core.Integer;
            offsetX: nasl.core.Integer;
            offsetY: nasl.core.Integer;
            pageX: nasl.core.Integer;
            pageY: nasl.core.Integer;
            screenX: nasl.core.Integer;
            screenY: nasl.core.Integer;
            which: nasl.core.Integer;
        }) => any;
        onMouseDown: (event: {
            altKey: nasl.core.Boolean;
            button: nasl.core.Integer;
            clientX: nasl.core.Integer;
            clientY: nasl.core.Integer;
            ctrlKey: nasl.core.Boolean;
            metaKey: nasl.core.Boolean;
            movementX: nasl.core.Integer;
            movementY: nasl.core.Integer;
            offsetX: nasl.core.Integer;
            offsetY: nasl.core.Integer;
            pageX: nasl.core.Integer;
            pageY: nasl.core.Integer;
            screenX: nasl.core.Integer;
            screenY: nasl.core.Integer;
            which: nasl.core.Integer;
        }) => any;
        onMouseUp: (event: {
            altKey: nasl.core.Boolean;
            button: nasl.core.Integer;
            clientX: nasl.core.Integer;
            clientY: nasl.core.Integer;
            ctrlKey: nasl.core.Boolean;
            metaKey: nasl.core.Boolean;
            movementX: nasl.core.Integer;
            movementY: nasl.core.Integer;
            offsetX: nasl.core.Integer;
            offsetY: nasl.core.Integer;
            pageX: nasl.core.Integer;
            pageY: nasl.core.Integer;
            screenX: nasl.core.Integer;
            screenY: nasl.core.Integer;
            which: nasl.core.Integer;
        }) => any;
        onMouseEnter: (event: {
            altKey: nasl.core.Boolean;
            button: nasl.core.Integer;
            clientX: nasl.core.Integer;
            clientY: nasl.core.Integer;
            ctrlKey: nasl.core.Boolean;
            metaKey: nasl.core.Boolean;
            movementX: nasl.core.Integer;
            movementY: nasl.core.Integer;
            offsetX: nasl.core.Integer;
            offsetY: nasl.core.Integer;
            pageX: nasl.core.Integer;
            pageY: nasl.core.Integer;
            screenX: nasl.core.Integer;
            screenY: nasl.core.Integer;
            which: nasl.core.Integer;
        }) => any;
        onMouseLeave: (event: {
            altKey: nasl.core.Boolean;
            button: nasl.core.Integer;
            clientX: nasl.core.Integer;
            clientY: nasl.core.Integer;
            ctrlKey: nasl.core.Boolean;
            metaKey: nasl.core.Boolean;
            movementX: nasl.core.Integer;
            movementY: nasl.core.Integer;
            offsetX: nasl.core.Integer;
            offsetY: nasl.core.Integer;
            pageX: nasl.core.Integer;
            pageY: nasl.core.Integer;
            screenX: nasl.core.Integer;
            screenY: nasl.core.Integer;
            which: nasl.core.Integer;
        }) => any;
        onFocus: (event: {
            cancelBubble: nasl.core.Boolean;
            detail: nasl.core.String;
            layerX: nasl.core.Integer;
            layerY: nasl.core.Integer;
            pageX: nasl.core.Integer;
            pageY: nasl.core.Integer;
            which: nasl.core.Integer;
        }) => any;
        onBlur: (event: {
            cancelBubble: nasl.core.Boolean;
            detail: nasl.core.String;
            layerX: nasl.core.Integer;
            layerY: nasl.core.Integer;
            pageX: nasl.core.Integer;
            pageY: nasl.core.Integer;
            which: nasl.core.Integer;
        }) => any;
    }
}
declare namespace nasl.ui {
    class Card extends ViewComponent {
        constructor(options?: Partial<CardOptions>);
    }
    class CardOptions extends ViewComponentOptions {
        private content;
        private title;
        bordered: nasl.core.Boolean;
        boxShadow: nasl.core.Boolean;
        slotDefault: () => Array<ViewComponent>;
        slotTitle: () => Array<ViewComponent>;
        slotExtra: () => Array<ViewComponent>;
    }
}
declare namespace nasl.ui {
    class Cascader<T, V> extends ViewComponent {
        data: CascaderOptions<T, V>['dataSource'];
        value: CascaderOptions<T, V>['value'];
        open(): void;
        close(): void;
        reload(): void;
        constructor(options?: Partial<CascaderOptions<T, V>>);
    }
    class CascaderOptions<T, V> extends ViewComponentOptions {
        dataSource: nasl.collection.List<T> | {
            list: nasl.collection.List<T>;
            total: nasl.core.Integer;
        };
        dataSchema: T;
        textField: (item: T) => any;
        valueField: (item: T) => V;
        childrenField: (item: T) => nasl.collection.List<any>;
        parentField: (item: T) => any;
        value: V;
        showSearch: nasl.core.Boolean;
        placeholder: nasl.core.String;
        autoFocus: nasl.core.Boolean;
        expandTrigger: 'click' | 'hover';
        allowClear: nasl.core.Boolean;
        disabled: nasl.core.Boolean;
        open: nasl.core.Boolean;
        private join;
        onSearch: (event: V) => any;
        onChange: (event: {
            value: V;
            values: nasl.collection.List<V>;
            items: nasl.collection.List<T>;
        }) => any;
        onFocus: (event: {
            cancelBubble: nasl.core.Boolean;
            detail: nasl.core.String;
            layerX: nasl.core.Integer;
            layerY: nasl.core.Integer;
            pageX: nasl.core.Integer;
            pageY: nasl.core.Integer;
            which: nasl.core.Integer;
        }) => any;
        onBlur: (event: {
            cancelBubble: nasl.core.Boolean;
            detail: nasl.core.String;
            layerX: nasl.core.Integer;
            layerY: nasl.core.Integer;
            pageX: nasl.core.Integer;
            pageY: nasl.core.Integer;
            which: nasl.core.Integer;
        }) => any;
    }
}
declare namespace nasl.ui {
    class DatePicker extends ViewComponent {
        constructor(options?: Partial<DatePickerOptions>);
    }
    class DatePickerOptions extends ViewComponentOptions {
        picker: 'date' | 'week' | 'month' | 'quarter' | 'year';
        value: nasl.core.Date;
        showTime: nasl.core.Boolean;
        autoFocus: nasl.core.Boolean;
        placeholder: nasl.core.String;
        allowClear: nasl.core.Boolean;
        disabled: nasl.core.Boolean;
        open: nasl.core.Boolean;
        onChange: (event: {
            date: nasl.core.String;
            time: nasl.core.String;
        }) => any;
        onOpenChange: (event: {
            opened: nasl.core.Boolean;
        }) => any;
        onBlur: (event: {
            cancelBubble: nasl.core.Boolean;
            detail: nasl.core.String;
            layerX: nasl.core.Integer;
            layerY: nasl.core.Integer;
            pageX: nasl.core.Integer;
            pageY: nasl.core.Integer;
            which: nasl.core.Integer;
        }) => any;
    }
}
declare namespace nasl.ui {
    class DateRangePicker extends ViewComponent {
        constructor(options?: Partial<DatePickerOptions>);
    }
    class DateRangePickerOptions extends ViewComponentOptions {
        picker: 'date' | 'week' | 'month' | 'quarter' | 'year';
        value: Array<nasl.core.Date>;
        showTime: nasl.core.Boolean;
        autoFocus: nasl.core.Boolean;
        allowClear: nasl.core.Boolean;
        disabled: nasl.core.Boolean;
        open: nasl.core.Boolean;
        onChange: (event: {
            date: nasl.core.String;
            time: nasl.core.String;
        }) => any;
        onOpenChange: (event: {
            opened: nasl.core.Boolean;
        }) => any;
        onBlur: (event: {
            cancelBubble: nasl.core.Boolean;
            detail: nasl.core.String;
            layerX: nasl.core.Integer;
            layerY: nasl.core.Integer;
            pageX: nasl.core.Integer;
            pageY: nasl.core.Integer;
            which: nasl.core.Integer;
        }) => any;
    }
}
declare namespace nasl.ui {
    class Descriptions extends ViewComponent {
        constructor(options?: Partial<DescriptionsOptions>);
    }
    class DescriptionsOptions extends ViewComponentOptions {
        column: nasl.core.Decimal;
        slotDefault: () => Array<DescriptionsItem>;
    }
    class DescriptionsItem extends ViewComponent {
        constructor(options?: Partial<DescriptionsItemOptions>);
    }
    class DescriptionsItemOptions extends ViewComponentOptions {
        span: nasl.core.Decimal;
        ellipsis: nasl.core.Boolean;
        slotDefault: () => Array<ViewComponent>;
        slotLabel: () => Array<ViewComponent>;
    }
}
declare namespace nasl.ui {
    class Drawer extends ViewComponent {
        open(): void;
        close(): void;
        constructor(options?: Partial<DrawerOptions>);
    }
    class DrawerOptions extends ViewComponentOptions {
        placement: 'top' | 'bottom' | 'left' | 'right';
        mask: nasl.core.Boolean;
        maskClosable: nasl.core.Boolean;
        open: nasl.core.Boolean;
        width: nasl.core.Integer;
        afterOpenChange: (event: any) => any;
        onClose: (event: {
            ok: nasl.core.Boolean;
        }) => any;
        slotTitle: () => Array<ViewComponent>;
        slotDefault: () => Array<ViewComponent>;
        slotFooter: () => Array<ViewComponent>;
        slotExtra: () => Array<ViewComponent>;
    }
}
declare namespace nasl.ui {
    class Dropdown<T, V> extends ViewComponent {
        constructor(options?: Partial<DropdownOptions<T, V>>);
    }
    class DropdownOptions<T, V> extends ViewComponentOptions {
        dataSource: nasl.collection.List<T> | {
            list: nasl.collection.List<T>;
            total: nasl.core.Integer;
        };
        dataSchema: T;
        textField: (item: T) => any;
        valueField: (item: T) => V;
        trigger: 'click' | 'hover' | 'contextMenu';
        disabled: nasl.core.Boolean;
        slotMenuItem: () => Array<ViewComponent>;
        slotDefault: () => Array<ViewComponent>;
    }
}
declare namespace nasl.ui {
    class Flex extends ViewComponent {
        constructor(options?: Partial<FlexOptions>);
    }
    class FlexOptions extends ViewComponentOptions {
        private display;
        private type;
        scroll: nasl.core.Boolean;
        direction: 'horizontal' | 'vertical';
        justify: 'start' | 'center' | 'end' | 'space-between' | 'space-around';
        alignment: 'start' | 'center' | 'end' | 'baseline' | 'stretch';
        wrap: 'wrap' | 'nowrap';
        gap: 'small' | 'middle' | 'large' | 0;
        onClick: (event: {
            altKey: nasl.core.Boolean;
            button: nasl.core.Integer;
            clientX: nasl.core.Integer;
            clientY: nasl.core.Integer;
            ctrlKey: nasl.core.Boolean;
            metaKey: nasl.core.Boolean;
            movementX: nasl.core.Integer;
            movementY: nasl.core.Integer;
            offsetX: nasl.core.Integer;
            offsetY: nasl.core.Integer;
            pageX: nasl.core.Integer;
            pageY: nasl.core.Integer;
            screenX: nasl.core.Integer;
            screenY: nasl.core.Integer;
            which: nasl.core.Integer;
        }) => any;
        onDoubleClick: (event: {
            altKey: nasl.core.Boolean;
            button: nasl.core.Integer;
            clientX: nasl.core.Integer;
            clientY: nasl.core.Integer;
            ctrlKey: nasl.core.Boolean;
            metaKey: nasl.core.Boolean;
            movementX: nasl.core.Integer;
            movementY: nasl.core.Integer;
            offsetX: nasl.core.Integer;
            offsetY: nasl.core.Integer;
            pageX: nasl.core.Integer;
            pageY: nasl.core.Integer;
            screenX: nasl.core.Integer;
            screenY: nasl.core.Integer;
            which: nasl.core.Integer;
        }) => any;
        onContextMenu: (event: {
            altKey: nasl.core.Boolean;
            button: nasl.core.Integer;
            clientX: nasl.core.Integer;
            clientY: nasl.core.Integer;
            ctrlKey: nasl.core.Boolean;
            metaKey: nasl.core.Boolean;
            movementX: nasl.core.Integer;
            movementY: nasl.core.Integer;
            offsetX: nasl.core.Integer;
            offsetY: nasl.core.Integer;
            pageX: nasl.core.Integer;
            pageY: nasl.core.Integer;
            screenX: nasl.core.Integer;
            screenY: nasl.core.Integer;
            which: nasl.core.Integer;
        }) => any;
        onMouseDown: (event: {
            altKey: nasl.core.Boolean;
            button: nasl.core.Integer;
            clientX: nasl.core.Integer;
            clientY: nasl.core.Integer;
            ctrlKey: nasl.core.Boolean;
            metaKey: nasl.core.Boolean;
            movementX: nasl.core.Integer;
            movementY: nasl.core.Integer;
            offsetX: nasl.core.Integer;
            offsetY: nasl.core.Integer;
            pageX: nasl.core.Integer;
            pageY: nasl.core.Integer;
            screenX: nasl.core.Integer;
            screenY: nasl.core.Integer;
            which: nasl.core.Integer;
        }) => any;
        onMouseUp: (event: {
            altKey: nasl.core.Boolean;
            button: nasl.core.Integer;
            clientX: nasl.core.Integer;
            clientY: nasl.core.Integer;
            ctrlKey: nasl.core.Boolean;
            metaKey: nasl.core.Boolean;
            movementX: nasl.core.Integer;
            movementY: nasl.core.Integer;
            offsetX: nasl.core.Integer;
            offsetY: nasl.core.Integer;
            pageX: nasl.core.Integer;
            pageY: nasl.core.Integer;
            screenX: nasl.core.Integer;
            screenY: nasl.core.Integer;
            which: nasl.core.Integer;
        }) => any;
        onMouseEnter: (event: {
            altKey: nasl.core.Boolean;
            button: nasl.core.Integer;
            clientX: nasl.core.Integer;
            clientY: nasl.core.Integer;
            ctrlKey: nasl.core.Boolean;
            metaKey: nasl.core.Boolean;
            movementX: nasl.core.Integer;
            movementY: nasl.core.Integer;
            offsetX: nasl.core.Integer;
            offsetY: nasl.core.Integer;
            pageX: nasl.core.Integer;
            pageY: nasl.core.Integer;
            screenX: nasl.core.Integer;
            screenY: nasl.core.Integer;
            which: nasl.core.Integer;
        }) => any;
        onMouseLeave: (event: {
            altKey: nasl.core.Boolean;
            button: nasl.core.Integer;
            clientX: nasl.core.Integer;
            clientY: nasl.core.Integer;
            ctrlKey: nasl.core.Boolean;
            metaKey: nasl.core.Boolean;
            movementX: nasl.core.Integer;
            movementY: nasl.core.Integer;
            offsetX: nasl.core.Integer;
            offsetY: nasl.core.Integer;
            pageX: nasl.core.Integer;
            pageY: nasl.core.Integer;
            screenX: nasl.core.Integer;
            screenY: nasl.core.Integer;
            which: nasl.core.Integer;
        }) => any;
        onScroll: (event: {
            scrollTop: nasl.core.Integer;
            scrollLeft: nasl.core.Integer;
            scrollWidth: nasl.core.Integer;
            scrollHeight: nasl.core.Integer;
            clientWidth: nasl.core.Integer;
            clientHeight: nasl.core.Integer;
        }) => any;
        slotDefault: () => Array<ViewComponent>;
    }
}
declare namespace nasl.ui {
    class Form extends ViewComponent {
        validate(): any;
        getValues(): any;
        getValue(name: nasl.core.String): any;
        setValue(name: nasl.core.String, value: any): any;
        constructor(options?: Partial<FormOptions>);
    }
    class FormOptions extends ViewComponentOptions {
        private model;
        private size;
        private rules;
        layout: 'inline' | 'horizontal' | 'vertical';
        gutterJustify: nasl.core.Decimal;
        gutterAlign: nasl.core.Decimal;
        justify: 'start' | 'center' | 'end' | 'space-between' | 'space-around';
        alignment: 'start' | 'center' | 'end' | 'baseline' | 'stretch';
        wrap: 'wrap' | 'nowrap';
        onChange: (event: {
            rawValue: nasl.core.String;
            value: nasl.core.String;
            trigger: nasl.core.String;
            muted: nasl.core.String;
            valid: nasl.core.Boolean;
            touched: nasl.core.Boolean;
            dirty: nasl.core.Boolean;
            firstError: nasl.core.String;
            triggerValid: nasl.core.Boolean;
        }) => any;
        onFinish: (event: {
            rawValue: nasl.core.String;
            value: nasl.core.String;
            trigger: nasl.core.String;
            muted: nasl.core.String;
            valid: nasl.core.Boolean;
            touched: nasl.core.Boolean;
            dirty: nasl.core.Boolean;
            firstError: nasl.core.String;
            triggerValid: nasl.core.Boolean;
        }) => any;
        slotDefault: () => Array<FormItem>;
    }
}
declare namespace nasl.ui {
    class Image extends ViewComponent {
        constructor(options?: Partial<ImageOptions>);
    }
    class ImageOptions extends ViewComponentOptions {
        private convertSrcFn;
        src: nasl.core.String;
        preview: nasl.core.Boolean;
        fallback: nasl.core.String;
        onLoad: (event: any) => any;
        onClick: (event: {
            altKey: nasl.core.Boolean;
            button: nasl.core.Integer;
            clientX: nasl.core.Integer;
            clientY: nasl.core.Integer;
            ctrlKey: nasl.core.Boolean;
            metaKey: nasl.core.Boolean;
            movementX: nasl.core.Integer;
            movementY: nasl.core.Integer;
            offsetX: nasl.core.Integer;
            offsetY: nasl.core.Integer;
            pageX: nasl.core.Integer;
            pageY: nasl.core.Integer;
            screenX: nasl.core.Integer;
            screenY: nasl.core.Integer;
            which: nasl.core.Integer;
        }) => any;
        onDoubleClick: (event: {
            altKey: nasl.core.Boolean;
            button: nasl.core.Integer;
            clientX: nasl.core.Integer;
            clientY: nasl.core.Integer;
            ctrlKey: nasl.core.Boolean;
            metaKey: nasl.core.Boolean;
            movementX: nasl.core.Integer;
            movementY: nasl.core.Integer;
            offsetX: nasl.core.Integer;
            offsetY: nasl.core.Integer;
            pageX: nasl.core.Integer;
            pageY: nasl.core.Integer;
            screenX: nasl.core.Integer;
            screenY: nasl.core.Integer;
            which: nasl.core.Integer;
        }) => any;
        onContextMenu: (event: {
            altKey: nasl.core.Boolean;
            button: nasl.core.Integer;
            clientX: nasl.core.Integer;
            clientY: nasl.core.Integer;
            ctrlKey: nasl.core.Boolean;
            metaKey: nasl.core.Boolean;
            movementX: nasl.core.Integer;
            movementY: nasl.core.Integer;
            offsetX: nasl.core.Integer;
            offsetY: nasl.core.Integer;
            pageX: nasl.core.Integer;
            pageY: nasl.core.Integer;
            screenX: nasl.core.Integer;
            screenY: nasl.core.Integer;
            which: nasl.core.Integer;
        }) => any;
        onMouseDown: (event: {
            altKey: nasl.core.Boolean;
            button: nasl.core.Integer;
            clientX: nasl.core.Integer;
            clientY: nasl.core.Integer;
            ctrlKey: nasl.core.Boolean;
            metaKey: nasl.core.Boolean;
            movementX: nasl.core.Integer;
            movementY: nasl.core.Integer;
            offsetX: nasl.core.Integer;
            offsetY: nasl.core.Integer;
            pageX: nasl.core.Integer;
            pageY: nasl.core.Integer;
            screenX: nasl.core.Integer;
            screenY: nasl.core.Integer;
            which: nasl.core.Integer;
        }) => any;
        onMouseUp: (event: {
            altKey: nasl.core.Boolean;
            button: nasl.core.Integer;
            clientX: nasl.core.Integer;
            clientY: nasl.core.Integer;
            ctrlKey: nasl.core.Boolean;
            metaKey: nasl.core.Boolean;
            movementX: nasl.core.Integer;
            movementY: nasl.core.Integer;
            offsetX: nasl.core.Integer;
            offsetY: nasl.core.Integer;
            pageX: nasl.core.Integer;
            pageY: nasl.core.Integer;
            screenX: nasl.core.Integer;
            screenY: nasl.core.Integer;
            which: nasl.core.Integer;
        }) => any;
        onMouseEnter: (event: {
            altKey: nasl.core.Boolean;
            button: nasl.core.Integer;
            clientX: nasl.core.Integer;
            clientY: nasl.core.Integer;
            ctrlKey: nasl.core.Boolean;
            metaKey: nasl.core.Boolean;
            movementX: nasl.core.Integer;
            movementY: nasl.core.Integer;
            offsetX: nasl.core.Integer;
            offsetY: nasl.core.Integer;
            pageX: nasl.core.Integer;
            pageY: nasl.core.Integer;
            screenX: nasl.core.Integer;
            screenY: nasl.core.Integer;
            which: nasl.core.Integer;
        }) => any;
        onMouseLeave: (event: {
            altKey: nasl.core.Boolean;
            button: nasl.core.Integer;
            clientX: nasl.core.Integer;
            clientY: nasl.core.Integer;
            ctrlKey: nasl.core.Boolean;
            metaKey: nasl.core.Boolean;
            movementX: nasl.core.Integer;
            movementY: nasl.core.Integer;
            offsetX: nasl.core.Integer;
            offsetY: nasl.core.Integer;
            pageX: nasl.core.Integer;
            pageY: nasl.core.Integer;
            screenX: nasl.core.Integer;
            screenY: nasl.core.Integer;
            which: nasl.core.Integer;
        }) => any;
    }
}
declare namespace nasl.ui {
    class FormInputNumber extends ViewComponent {
        constructor(options?: Partial<FormInputNumberOptions>);
    }
    class FormInputNumberOptions extends ViewComponentOptions {
        labelIsSlot: nasl.core.Boolean;
        labelText: nasl.core.String;
        name: nasl.core.String;
        span: nasl.core.Decimal;
        required: nasl.core.Boolean;
        tooltip: nasl.core.String;
        rules: nasl.core.String;
        type: 'text' | 'password';
        value: nasl.core.String;
        placeholder: nasl.core.String;
        maxlength: nasl.core.Integer;
        prefix: nasl.core.String;
        suffix: nasl.core.String;
        allowClear: nasl.core.Boolean;
        disabled: nasl.core.Boolean;
        showCount: nasl.core.Boolean;
        onChange: (event: {
            value: nasl.core.String;
            oldValue: nasl.core.String;
        }) => any;
        onFocus: (event: {
            cancelBubble: nasl.core.Boolean;
            detail: nasl.core.String;
            layerX: nasl.core.Integer;
            layerY: nasl.core.Integer;
            pageX: nasl.core.Integer;
            pageY: nasl.core.Integer;
            which: nasl.core.Integer;
        }) => any;
        onBlur: (event: {
            cancelBubble: nasl.core.Boolean;
            detail: nasl.core.String;
            layerX: nasl.core.Integer;
            layerY: nasl.core.Integer;
            pageX: nasl.core.Integer;
            pageY: nasl.core.Integer;
            which: nasl.core.Integer;
        }) => any;
        onKeyDown: (event: {
            altKey: nasl.core.Boolean;
            code: nasl.core.String;
            ctrlKey: nasl.core.Boolean;
            isComposing: nasl.core.Boolean;
            key: nasl.core.String;
            metaKey: nasl.core.Boolean;
            repeat: nasl.core.Boolean;
            shiftKey: nasl.core.Boolean;
        }) => any;
        onKeyUp: (event: {
            altKey: nasl.core.Boolean;
            code: nasl.core.String;
            ctrlKey: nasl.core.Boolean;
            isComposing: nasl.core.Boolean;
            key: nasl.core.String;
            metaKey: nasl.core.Boolean;
            repeat: nasl.core.Boolean;
            shiftKey: nasl.core.Boolean;
        }) => any;
    }
}
declare namespace nasl.ui {
    class InputNumber extends ViewComponent {
        constructor(options?: Partial<InputNumberOptions>);
    }
    class InputNumberOptions extends ViewComponentOptions {
        private formatter;
        value: nasl.core.Decimal;
        min: nasl.core.Decimal;
        max: nasl.core.Decimal;
        private precision;
        prefix: nasl.core.String;
        placeholder: nasl.core.String;
        autoFocus: nasl.core.Boolean;
        controls: nasl.core.Boolean;
        readOnly: nasl.core.Boolean;
        disabled: nasl.core.Boolean;
        step: nasl.core.Decimal;
        onChange: (event: {
            value: nasl.core.Decimal;
            oldValue: nasl.core.Decimal;
            formattedValue: nasl.core.String;
            valid: nasl.core.Boolean;
        }) => any;
        onFocus: (event: {
            cancelBubble: nasl.core.Boolean;
            detail: nasl.core.String;
            layerX: nasl.core.Integer;
            layerY: nasl.core.Integer;
            pageX: nasl.core.Integer;
            pageY: nasl.core.Integer;
            which: nasl.core.Integer;
        }) => any;
        onBlur: (event: {
            cancelBubble: nasl.core.Boolean;
            detail: nasl.core.String;
            layerX: nasl.core.Integer;
            layerY: nasl.core.Integer;
            pageX: nasl.core.Integer;
            pageY: nasl.core.Integer;
            which: nasl.core.Integer;
        }) => any;
        onKeyDown: (event: {
            altKey: nasl.core.Boolean;
            code: nasl.core.String;
            ctrlKey: nasl.core.Boolean;
            isComposing: nasl.core.Boolean;
            key: nasl.core.String;
            metaKey: nasl.core.Boolean;
            repeat: nasl.core.Boolean;
            shiftKey: nasl.core.Boolean;
        }) => any;
        onKeyUp: (event: {
            altKey: nasl.core.Boolean;
            code: nasl.core.String;
            ctrlKey: nasl.core.Boolean;
            isComposing: nasl.core.Boolean;
            key: nasl.core.String;
            metaKey: nasl.core.Boolean;
            repeat: nasl.core.Boolean;
            shiftKey: nasl.core.Boolean;
        }) => any;
        slotDefault: () => Array<ViewComponent>;
    }
}
declare namespace nasl.ui {
    class Layout extends ViewComponent {
        constructor(options?: Partial<LayoutOptions>);
    }
    class LayoutOptions extends ViewComponentOptions {
        slotDefault: () => Array<ViewComponent>;
    }
    class Header extends ViewComponent {
        constructor(options?: Partial<HeaderOptions>);
    }
    class HeaderOptions extends ViewComponentOptions {
        slotDefault: () => Array<ViewComponent>;
    }
}
declare namespace nasl.ui {
    class Link extends ViewComponent {
        constructor(options?: Partial<LinkOptions>);
    }
    class LinkOptions extends ViewComponentOptions {
        children: nasl.core.String;
        hrefAndTo: nasl.core.String;
        target: '_blank' | '_self' | '_parent' | '_top';
        slotDefault: () => Array<ViewComponent>;
        disabled: nasl.core.Boolean;
        onClick: (event: {
            altKey: nasl.core.Boolean;
            button: nasl.core.Integer;
            clientX: nasl.core.Integer;
            clientY: nasl.core.Integer;
            ctrlKey: nasl.core.Boolean;
            metaKey: nasl.core.Boolean;
            movementX: nasl.core.Integer;
            movementY: nasl.core.Integer;
            offsetX: nasl.core.Integer;
            offsetY: nasl.core.Integer;
            pageX: nasl.core.Integer;
            pageY: nasl.core.Integer;
            screenX: nasl.core.Integer;
            screenY: nasl.core.Integer;
            which: nasl.core.Integer;
        }) => any;
        onDoubleClick: (event: {
            altKey: nasl.core.Boolean;
            button: nasl.core.Integer;
            clientX: nasl.core.Integer;
            clientY: nasl.core.Integer;
            ctrlKey: nasl.core.Boolean;
            metaKey: nasl.core.Boolean;
            movementX: nasl.core.Integer;
            movementY: nasl.core.Integer;
            offsetX: nasl.core.Integer;
            offsetY: nasl.core.Integer;
            pageX: nasl.core.Integer;
            pageY: nasl.core.Integer;
            screenX: nasl.core.Integer;
            screenY: nasl.core.Integer;
            which: nasl.core.Integer;
        }) => any;
        onContextMenu: (event: {
            altKey: nasl.core.Boolean;
            button: nasl.core.Integer;
            clientX: nasl.core.Integer;
            clientY: nasl.core.Integer;
            ctrlKey: nasl.core.Boolean;
            metaKey: nasl.core.Boolean;
            movementX: nasl.core.Integer;
            movementY: nasl.core.Integer;
            offsetX: nasl.core.Integer;
            offsetY: nasl.core.Integer;
            pageX: nasl.core.Integer;
            pageY: nasl.core.Integer;
            screenX: nasl.core.Integer;
            screenY: nasl.core.Integer;
            which: nasl.core.Integer;
        }) => any;
        onMouseDown: (event: {
            altKey: nasl.core.Boolean;
            button: nasl.core.Integer;
            clientX: nasl.core.Integer;
            clientY: nasl.core.Integer;
            ctrlKey: nasl.core.Boolean;
            metaKey: nasl.core.Boolean;
            movementX: nasl.core.Integer;
            movementY: nasl.core.Integer;
            offsetX: nasl.core.Integer;
            offsetY: nasl.core.Integer;
            pageX: nasl.core.Integer;
            pageY: nasl.core.Integer;
            screenX: nasl.core.Integer;
            screenY: nasl.core.Integer;
            which: nasl.core.Integer;
        }) => any;
        onMouseUp: (event: {
            altKey: nasl.core.Boolean;
            button: nasl.core.Integer;
            clientX: nasl.core.Integer;
            clientY: nasl.core.Integer;
            ctrlKey: nasl.core.Boolean;
            metaKey: nasl.core.Boolean;
            movementX: nasl.core.Integer;
            movementY: nasl.core.Integer;
            offsetX: nasl.core.Integer;
            offsetY: nasl.core.Integer;
            pageX: nasl.core.Integer;
            pageY: nasl.core.Integer;
            screenX: nasl.core.Integer;
            screenY: nasl.core.Integer;
            which: nasl.core.Integer;
        }) => any;
        onMouseEnter: (event: {
            altKey: nasl.core.Boolean;
            button: nasl.core.Integer;
            clientX: nasl.core.Integer;
            clientY: nasl.core.Integer;
            ctrlKey: nasl.core.Boolean;
            metaKey: nasl.core.Boolean;
            movementX: nasl.core.Integer;
            movementY: nasl.core.Integer;
            offsetX: nasl.core.Integer;
            offsetY: nasl.core.Integer;
            pageX: nasl.core.Integer;
            pageY: nasl.core.Integer;
            screenX: nasl.core.Integer;
            screenY: nasl.core.Integer;
            which: nasl.core.Integer;
        }) => any;
        onMouseLeave: (event: {
            altKey: nasl.core.Boolean;
            button: nasl.core.Integer;
            clientX: nasl.core.Integer;
            clientY: nasl.core.Integer;
            ctrlKey: nasl.core.Boolean;
            metaKey: nasl.core.Boolean;
            movementX: nasl.core.Integer;
            movementY: nasl.core.Integer;
            offsetX: nasl.core.Integer;
            offsetY: nasl.core.Integer;
            pageX: nasl.core.Integer;
            pageY: nasl.core.Integer;
            screenX: nasl.core.Integer;
            screenY: nasl.core.Integer;
            which: nasl.core.Integer;
        }) => any;
    }
}
declare namespace nasl.ui {
    class List<T, V, P extends nasl.core.Boolean, M extends nasl.core.Boolean, C extends string> extends ViewComponent {
        data: ListOptions<T, V, P, M, C>['dataSource'];
        pageSize: ListOptions<T, V, P, M, C>['pageSize'];
        current: ListOptions<T, V, P, M, C>['current'];
        filterText: nasl.core.String;
        reload(): void;
        constructor(options?: Partial<ListOptions<T, V, P, M, C>>);
    }
    class ListOptions<T, V, P extends nasl.core.Boolean, M extends nasl.core.Boolean, C extends string> extends ViewComponentOptions {
        dataSource: {
            list: nasl.collection.List<T>;
            total: nasl.core.Integer;
        } | nasl.collection.List<T>;
        dataSchema: T;
        pagination: nasl.core.Boolean;
        pageSize: nasl.core.Integer;
        current: nasl.core.Integer;
        pageSizeOptions: Array<nasl.core.Integer>;
        showTotal: nasl.core.Boolean;
        showSizeChanger: nasl.core.Boolean;
        showQuickJumper: nasl.core.Boolean;
        bordered: nasl.core.Boolean;
        slotRenderItem: (current: Current<T>) => Array<ViewComponent>;
    }
    class ListItem<T, V> extends ViewComponent {
        constructor(options?: Partial<ListItemOptions<T, V>>);
    }
    class ListItemOptions<T, V> extends ViewComponentOptions {
        slotDefault: (current: Current<T>) => Array<ViewComponent>;
        slotAvatar: (current: Current<T>) => Array<ViewComponent>;
        slotDescription: (current: Current<T>) => Array<ViewComponent>;
        slotTitle: (current: Current<T>) => Array<ViewComponent>;
    }
}
declare namespace nasl.ui {
    class Menu extends ViewComponent {
        constructor(options?: Partial<MenuOptions>);
    }
    class MenuOptions extends ViewComponentOptions {
        openKeys: nasl.core.String;
        onClick: (event: {
            altKey: nasl.core.Boolean;
            button: nasl.core.Integer;
            clientX: nasl.core.Integer;
            clientY: nasl.core.Integer;
            ctrlKey: nasl.core.Boolean;
            metaKey: nasl.core.Boolean;
            movementX: nasl.core.Integer;
            movementY: nasl.core.Integer;
            offsetX: nasl.core.Integer;
            offsetY: nasl.core.Integer;
            pageX: nasl.core.Integer;
            pageY: nasl.core.Integer;
            screenX: nasl.core.Integer;
            screenY: nasl.core.Integer;
            which: nasl.core.Integer;
        }) => any;
        onSelect: (event: {
            value: nasl.core.String;
            oldValue: nasl.core.String;
            selectedItem: nasl.core.Any;
            item: nasl.core.Any;
            oldItem: nasl.core.Any;
        }) => any;
        slotDefault: () => Array<MenuItem | MenuDivider>;
    }
    class MenuItem extends ViewComponent {
        constructor(options?: Partial<MenuItemOptions>);
    }
    class MenuItemOptions extends ViewComponentOptions {
        key: nasl.core.Any;
        icon: nasl.core.String;
        disabled: nasl.core.Boolean;
        private item;
        private to;
        private replace;
        private exact;
        onClick: (event: any) => any;
        slotLabel: () => Array<ViewComponent>;
        slotDefault: () => Array<ViewComponent>;
    }
    class MenuDivider extends ViewComponent {
        constructor(options?: Partial<MenuDividerOptions>);
    }
    class MenuDividerOptions extends ViewComponentOptions {
    }
    class MenuItemGroup extends ViewComponent {
        constructor(options?: Partial<MenuItemGroupOptions>);
    }
    class MenuItemGroupOptions extends ViewComponentOptions {
        title: nasl.core.String;
        key: nasl.core.Any;
        icon: nasl.core.String;
        slotDefault: () => Array<ViewComponent>;
    }
    class MenuSubMenu extends ViewComponent {
        constructor(options?: Partial<MenuSubMenuOptions>);
    }
    class MenuSubMenuOptions extends ViewComponentOptions {
        key: nasl.core.Any;
        icon: nasl.core.String;
        slotTitle: () => Array<ViewComponent>;
        slotDefault: () => Array<ViewComponent>;
    }
}
declare namespace nasl.ui {
    class UToastSingle extends ViewComponent {
        constructor(options?: Partial<UToastSingleOptions>);
    }
    class UToastSingleOptions extends ViewComponentOptions {
        content: nasl.core.String;
        type: 'success' | 'warning' | 'error';
        duration: nasl.core.Decimal;
        private position;
        onClose: (event: {
            text: nasl.core.String;
            color: nasl.core.String;
            duration: nasl.core.Integer;
            timestamp: nasl.core.Integer;
        }) => any;
        slotContent: () => Array<ViewComponent>;
    }
}
declare namespace nasl.ui {
    class Modal extends ViewComponent {
        open(): void;
        close(): void;
        constructor(options?: Partial<ModalOptions>);
    }
    class ModalOptions extends ViewComponentOptions {
        private content;
        private description;
        private static;
        closable: nasl.core.Boolean;
        keyboard: nasl.core.Boolean;
        mask: nasl.core.Boolean;
        maskClosable: nasl.core.Boolean;
        width: nasl.core.Integer;
        afterOpenChange: (event: Boolean) => any;
        onCancel: (event: any) => any;
        slotTitle: () => Array<ViewComponent>;
        slotDefault: () => Array<ViewComponent>;
        slotFooter: () => Array<ViewComponent>;
    }
}
declare namespace nasl.ui {
    class Popover extends ViewComponent {
        open(): void;
        close(): void;
        toggle(opened?: nasl.core.Boolean): void;
        constructor(options?: Partial<PopoverOptions>);
    }
    class PopoverOptions extends ViewComponentOptions {
        private offset;
        private mergeBorders;
        placement: 'top' | 'bottom' | 'left' | 'right' | 'topLeft' | 'topRight' | 'bottomLeft' | 'bottomRight' | 'leftTop' | 'leftBottom' | 'rightTop' | 'rightBottom';
        mouseEnterDelay: nasl.core.Decimal;
        mouseLeaveDelay: nasl.core.Decimal;
        trigger: 'click' | 'hover' | 'manual';
        open: nasl.core.Boolean;
        onOpenChange: (event: any) => any;
        slotContent: () => Array<ViewComponent>;
        slotTitle: () => Array<ViewComponent>;
        slotDefault: () => Array<ViewComponent>;
    }
}
declare namespace nasl.ui {
    class Radio extends ViewComponent {
        constructor(options?: Partial<RadioOptions>);
    }
    class RadioOptions extends ViewComponentOptions {
        value: nasl.core.Any;
        disabled: nasl.core.Boolean;
        onChange: (event: {
            item: nasl.core.String;
            oldItem: nasl.core.String;
            value: nasl.core.String;
            oldValue: nasl.core.String;
            items: nasl.collection.List<nasl.core.String>;
            oldItems: nasl.collection.List<nasl.core.String>;
            values: nasl.collection.List<nasl.core.String>;
        }) => any;
        slotDefault: () => Array<ViewComponent>;
    }
    class RadioGroup<T, V, C extends string> extends ViewComponent {
        constructor(options?: Partial<RadioGroupOptions<T, V, C>>);
    }
    class RadioGroupOptions<T, V, C extends string> extends ViewComponentOptions {
        private item;
        dataSource: nasl.collection.List<T> | {
            list: nasl.collection.List<T>;
            total: nasl.core.Integer;
        };
        value: nasl.core.Any;
        textField: (item: T) => nasl.core.String;
        valueField: (item: T) => V;
        disabled: nasl.core.Boolean;
        size: 'small' | 'middle' | 'large';
        optionType: 'default' | 'button';
        onChange: (event: {
            selected: nasl.core.Boolean;
            item: nasl.core.String;
            oldItem: nasl.core.String;
            value: nasl.core.String;
            oldValue: nasl.core.String;
            items: nasl.collection.List<nasl.core.String>;
            oldItems: nasl.collection.List<nasl.core.String>;
        }) => any;
        slotDefault: () => Array<ViewComponent>;
    }
}
declare namespace nasl.ui {
    class Router extends ViewComponent {
        constructor(options?: Partial<RouterOptions>);
    }
    class RouterOptions extends ViewComponentOptions {
        disableKeepAlive: nasl.core.Boolean;
    }
}
declare namespace nasl.ui {
    class Row extends ViewComponent {
        constructor(options?: Partial<RowOptions>);
    }
    class RowOptions extends ViewComponentOptions {
        justify: 'start' | 'center' | 'end' | 'space-between' | 'space-around';
        align: 'top' | 'middle' | 'bottom' | 'stretch' | 'stretch';
        gutterJustify: nasl.core.Decimal;
        gutterAlign: nasl.core.Decimal;
        wrap: nasl.core.Boolean;
        slotDefault: () => Array<Col>;
    }
    class Col extends ViewComponent {
        constructor(options?: Partial<ColOptions>);
    }
    class ColOptions extends ViewComponentOptions {
        private xxl;
        private xl;
        private lg;
        private md;
        private sm;
        private xs;
        flex: string | number;
        span: nasl.core.Decimal;
        offset: nasl.core.Decimal;
        pull: nasl.core.Decimal;
        push: nasl.core.Decimal;
        order: nasl.core.Decimal;
        slotDefault: () => Array<ViewComponent>;
    }
}
declare namespace nasl.ui {
    class Select<T, V, P extends boolean, M extends boolean, C extends string> extends ViewComponent {
        opened: Boolean;
        current: TableOptions<T, V, P, M>['current'];
        reload(): void;
        constructor(options?: Partial<SelectOptions<T, V, P, M, C>>);
    }
    class SelectOptions<T, V, P extends boolean, M extends boolean, C extends string> extends ViewComponentOptions {
        dataSource: P extends true ? {
            list: nasl.collection.List<T>;
            total: nasl.core.Integer;
        } : nasl.collection.List<T>;
        dataSchema: T;
        value: M extends true ? (C extends '' ? nasl.collection.List<V> : nasl.core.String) : V;
        textField: (item: T) => nasl.core.String;
        valueField: (item: T) => V;
        private labelInValue;
        showSearch: nasl.core.Boolean;
        placeholder: nasl.core.String;
        autoFocus: nasl.core.Boolean;
        allowClear: nasl.core.Boolean;
        private cancelable;
        mode: 'single' | 'multiple';
        disabled: nasl.core.Boolean;
        size: 'small' | 'middle' | 'large';
        slotDefault: () => Array<SelectOption<T, V>>;
        onInputKeyDown: (event: V) => void;
        onSelect: (event: {
            value: V;
            items: nasl.collection.List<T>;
        }) => void;
        onChange: (event: {
            value: V;
            items: nasl.collection.List<T>;
        }) => void;
        onDropdownVisibleChange: (open: Boolean) => void;
        onBlur: (event: {
            cancelBubble: nasl.core.Boolean;
            detail: nasl.core.String;
            layerX: nasl.core.Integer;
            layerY: nasl.core.Integer;
            pageX: nasl.core.Integer;
            pageY: nasl.core.Integer;
            which: nasl.core.Integer;
        }) => void;
    }
    class SelectOption<T, V> extends ViewComponent {
        constructor(options?: Partial<ListItemOptions<T, V>>);
    }
    class SelectOptionOptions<T, V> extends ViewComponentOptions {
        label: nasl.core.String;
        value: V;
        disabled: nasl.core.Boolean;
        slotDefault: () => Array<ViewComponent>;
    }
    class SelectOptGroup<T, V> extends ViewComponent {
        constructor(options?: Partial<SelectOptGroupOptions<T, V>>);
    }
    class SelectOptGroupOptions<T, V> extends ViewComponentOptions {
        title: nasl.core.String;
    }
}
declare namespace nasl.ui {
    class Steps<T> extends ViewComponent {
        reload(): void;
        constructor(options?: Partial<StepsOptions<T>>);
    }
    class StepsOptions<T> extends ViewComponentOptions {
        dataSource: nasl.collection.List<T>;
        dataSchema: T;
        current: nasl.core.Decimal;
        direction: 'horizontal' | 'vertical';
        disabled: nasl.core.Boolean;
        size: 'default' | 'small';
        onChange: (event: {
            value: nasl.core.Integer;
            oldValue: nasl.core.Integer;
            item: T;
            oldItem: T;
        }) => any;
        slotDefault: () => Array<StepsItem>;
    }
    class StepsItem extends ViewComponent {
        constructor(options?: Partial<StepsItemOptions>);
    }
    class StepsItemOptions extends ViewComponentOptions {
        private title;
        private desc;
        status: 'wait' | 'process' | 'finish' | 'error';
        icon: nasl.core.String;
        disabled: nasl.core.Boolean;
        slotDefault: () => Array<ViewComponent>;
        slotTitle: () => Array<ViewComponent>;
        slotDescription: () => Array<ViewComponent>;
    }
}
declare namespace nasl.ui {
    class Switch extends ViewComponent {
        constructor(options?: Partial<SwitchOptions>);
    }
    class SwitchOptions extends ViewComponentOptions {
        value: nasl.core.Boolean;
        checkedChildren: nasl.core.String;
        unCheckedChildren: nasl.core.String;
        disabled: nasl.core.Boolean;
        onChange: (event: nasl.core.Boolean) => any;
    }
}
declare namespace nasl.ui {
    class Table<T, V, P extends nasl.core.Boolean, M extends nasl.core.Boolean> extends ViewComponent {
        data: TableOptions<T, V, P, M>['dataSource'];
        pageSize: TableOptions<T, V, P, M>['pageSize'];
        current: TableOptions<T, V, P, M>['current'];
        order: nasl.core.String;
        reload(): void;
        constructor(options?: Partial<TableOptions<T, V, P, M>>);
    }
    class TableOptions<T, V, P extends nasl.core.Boolean, M extends nasl.core.Boolean> extends ViewComponentOptions {
        dataSource: {
            list: nasl.collection.List<T>;
            total: nasl.core.Integer;
        } | nasl.collection.List<T>;
        dataSchema: T;
        private params;
        pagination: nasl.core.Boolean;
        pageSize: nasl.core.Integer;
        showSizeChanger: nasl.core.Boolean;
        pageSizeOptions: Array<nasl.core.Integer>;
        current: nasl.core.Integer;
        showTotal: nasl.core.Boolean;
        showQuickJumper: nasl.core.Boolean;
        rowKey: (item: T) => V;
        value: T | nasl.collection.List<T>;
        rowSelection: nasl.core.Boolean;
        rowSelectionType: 'checkbox' | 'radio';
        title: nasl.core.String;
        showHeader: nasl.core.Boolean;
        sticky: nasl.core.Boolean;
        stickyOffsetTop: nasl.core.Decimal;
        virtual: nasl.core.Boolean;
        loadingText: nasl.core.String;
        loading: nasl.core.Boolean;
        emptyText: nasl.core.String;
        scrollX?: nasl.core.Integer;
        scrollY?: nasl.core.Integer;
        bordered: nasl.core.Boolean;
        onBefore: (event: any) => any;
        onSuccess: (event: any) => any;
        onPageonChange: (event: {
            size: nasl.core.Integer;
            oldSize: nasl.core.Integer;
            number: nasl.core.Integer;
            oldNumber: nasl.core.Integer;
        }) => any;
        onRowClick: (event: {
            item: T;
            index: nasl.core.Integer;
            rowIndex: nasl.core.Integer;
        }) => any;
        onDoubleClick: (event: {
            item: T;
            index: nasl.core.Integer;
            rowIndex: nasl.core.Integer;
        }) => any;
        onChange: (event: {
            value: V;
            oldValue: V;
            item: T;
            oldItem: T;
            values: nasl.collection.List<V>;
            oldValues: nasl.collection.List<V>;
            items: nasl.collection.List<T>;
        }) => any;
        slotDefault: () => Array<TableColumn<T, V, P, M>>;
    }
    class TableColumn<T, V, P extends nasl.core.Boolean, M extends nasl.core.Boolean> extends ViewComponent {
        constructor(options?: Partial<TableColumnOptions<T, V, P, M>>);
    }
    class TableColumnOptions<T, V, P extends nasl.core.Boolean, M extends nasl.core.Boolean> extends ViewComponentOptions {
        private formatter;
        dataIndex: (item: T) => any;
        sorter: nasl.core.Boolean;
        defaultSortOrder: 'ascend' | 'descend';
        multiple: nasl.core.Integer;
        fixed: 'left' | 'right' | false;
        ellipsis: nasl.core.Boolean;
        hidden: nasl.core.Boolean;
        width: nasl.core.String | nasl.core.Decimal;
        colSpan: nasl.core.Integer;
        slotRender: (current: Current<T>) => Array<ViewComponent>;
        slotTitle: (current: Current<T>) => Array<ViewComponent>;
    }
}
declare namespace nasl.ui {
    class Tabs<T, V> extends ViewComponent {
        reload(): void;
        constructor(options?: Partial<TabsOptions<T, V>>);
    }
    class TabsOptions<T, V> extends ViewComponentOptions {
        private showScrollButtons;
        dataSource: nasl.collection.List<T> | {
            list: nasl.collection.List<T>;
            total: nasl.core.Integer;
        };
        dataSchema: T;
        textField: (item: T) => any;
        valueField: (item: T) => V;
        activeKey: nasl.core.String;
        type: 'line' | 'card';
        size: 'small' | 'middle' | 'large';
        onTabClick: (event: {
            altKey: nasl.core.Boolean;
            button: nasl.core.Integer;
            clientX: nasl.core.Integer;
            clientY: nasl.core.Integer;
            ctrlKey: nasl.core.Boolean;
            metaKey: nasl.core.Boolean;
            movementX: nasl.core.Integer;
            movementY: nasl.core.Integer;
            offsetX: nasl.core.Integer;
            offsetY: nasl.core.Integer;
            pageX: nasl.core.Integer;
            pageY: nasl.core.Integer;
            screenX: nasl.core.Integer;
            screenY: nasl.core.Integer;
            which: nasl.core.Integer;
        }) => any;
        onChange: (event: {
            selected: nasl.core.Boolean;
            item: T;
            oldItem: T;
            value: V;
            oldValue: V;
            items: nasl.collection.List<T>;
            oldItems: nasl.collection.List<T>;
        }) => any;
        slotDefault: () => Array<TabPane<V>>;
    }
    class TabPane<V> extends ViewComponent {
        constructor(options?: Partial<TabPaneOptions<V>>);
    }
    class TabPaneOptions<V> extends ViewComponentOptions {
        private title;
        key: V;
        disabled: nasl.core.Boolean;
        slotDefault: () => Array<ViewComponent>;
        slotTab: () => Array<ViewComponent>;
    }
}
declare namespace nasl.ui {
    class Tag extends ViewComponent {
        constructor(options?: Partial<TagOptions>);
    }
    class TagOptions extends ViewComponentOptions {
        children: nasl.core.String;
        color: 'default' | 'success' | 'warning' | 'error';
        closable: nasl.core.Boolean;
        onClick: (event: {
            altKey: nasl.core.Boolean;
            button: nasl.core.Integer;
            clientX: nasl.core.Integer;
            clientY: nasl.core.Integer;
            ctrlKey: nasl.core.Boolean;
            metaKey: nasl.core.Boolean;
            movementX: nasl.core.Integer;
            movementY: nasl.core.Integer;
            offsetX: nasl.core.Integer;
            offsetY: nasl.core.Integer;
            pageX: nasl.core.Integer;
            pageY: nasl.core.Integer;
            screenX: nasl.core.Integer;
            screenY: nasl.core.Integer;
            which: nasl.core.Integer;
        }) => any;
        onDoubleClick: (event: {
            altKey: nasl.core.Boolean;
            button: nasl.core.Integer;
            clientX: nasl.core.Integer;
            clientY: nasl.core.Integer;
            ctrlKey: nasl.core.Boolean;
            metaKey: nasl.core.Boolean;
            movementX: nasl.core.Integer;
            movementY: nasl.core.Integer;
            offsetX: nasl.core.Integer;
            offsetY: nasl.core.Integer;
            pageX: nasl.core.Integer;
            pageY: nasl.core.Integer;
            screenX: nasl.core.Integer;
            screenY: nasl.core.Integer;
            which: nasl.core.Integer;
        }) => any;
        onContextMenu: (event: {
            altKey: nasl.core.Boolean;
            button: nasl.core.Integer;
            clientX: nasl.core.Integer;
            clientY: nasl.core.Integer;
            ctrlKey: nasl.core.Boolean;
            metaKey: nasl.core.Boolean;
            movementX: nasl.core.Integer;
            movementY: nasl.core.Integer;
            offsetX: nasl.core.Integer;
            offsetY: nasl.core.Integer;
            pageX: nasl.core.Integer;
            pageY: nasl.core.Integer;
            screenX: nasl.core.Integer;
            screenY: nasl.core.Integer;
            which: nasl.core.Integer;
        }) => any;
        onMouseDown: (event: {
            altKey: nasl.core.Boolean;
            button: nasl.core.Integer;
            clientX: nasl.core.Integer;
            clientY: nasl.core.Integer;
            ctrlKey: nasl.core.Boolean;
            metaKey: nasl.core.Boolean;
            movementX: nasl.core.Integer;
            movementY: nasl.core.Integer;
            offsetX: nasl.core.Integer;
            offsetY: nasl.core.Integer;
            pageX: nasl.core.Integer;
            pageY: nasl.core.Integer;
            screenX: nasl.core.Integer;
            screenY: nasl.core.Integer;
            which: nasl.core.Integer;
        }) => any;
        onMouseUp: (event: {
            altKey: nasl.core.Boolean;
            button: nasl.core.Integer;
            clientX: nasl.core.Integer;
            clientY: nasl.core.Integer;
            ctrlKey: nasl.core.Boolean;
            metaKey: nasl.core.Boolean;
            movementX: nasl.core.Integer;
            movementY: nasl.core.Integer;
            offsetX: nasl.core.Integer;
            offsetY: nasl.core.Integer;
            pageX: nasl.core.Integer;
            pageY: nasl.core.Integer;
            screenX: nasl.core.Integer;
            screenY: nasl.core.Integer;
            which: nasl.core.Integer;
        }) => any;
        onMouseEnter: (event: {
            altKey: nasl.core.Boolean;
            button: nasl.core.Integer;
            clientX: nasl.core.Integer;
            clientY: nasl.core.Integer;
            ctrlKey: nasl.core.Boolean;
            metaKey: nasl.core.Boolean;
            movementX: nasl.core.Integer;
            movementY: nasl.core.Integer;
            offsetX: nasl.core.Integer;
            offsetY: nasl.core.Integer;
            pageX: nasl.core.Integer;
            pageY: nasl.core.Integer;
            screenX: nasl.core.Integer;
            screenY: nasl.core.Integer;
            which: nasl.core.Integer;
        }) => any;
        onMouseLeave: (event: {
            altKey: nasl.core.Boolean;
            button: nasl.core.Integer;
            clientX: nasl.core.Integer;
            clientY: nasl.core.Integer;
            ctrlKey: nasl.core.Boolean;
            metaKey: nasl.core.Boolean;
            movementX: nasl.core.Integer;
            movementY: nasl.core.Integer;
            offsetX: nasl.core.Integer;
            offsetY: nasl.core.Integer;
            pageX: nasl.core.Integer;
            pageY: nasl.core.Integer;
            screenX: nasl.core.Integer;
            screenY: nasl.core.Integer;
            which: nasl.core.Integer;
        }) => any;
        onClose: (event: any) => any;
        slotDefault: () => Array<ViewComponent>;
    }
}
declare namespace nasl.ui {
    class Text extends ViewComponent {
        constructor(options?: Partial<TextOptions>);
    }
    class TextOptions extends ViewComponentOptions {
        children: nasl.core.String;
        ellipsis: nasl.core.Boolean;
        editable: nasl.core.Boolean;
        copyable: nasl.core.Boolean;
        type?: 'default' | 'secondary' | 'success' | 'warning' | 'danger';
        code: nasl.core.Boolean;
        delete: nasl.core.Boolean;
        disabled: nasl.core.Boolean;
        keyboard: nasl.core.Boolean;
        mark: nasl.core.Boolean;
        strong: nasl.core.Boolean;
        italic: nasl.core.Boolean;
        underline: nasl.core.Boolean;
        onClick: (event: {
            altKey: nasl.core.Boolean;
            button: nasl.core.Integer;
            clientX: nasl.core.Integer;
            clientY: nasl.core.Integer;
            ctrlKey: nasl.core.Boolean;
            metaKey: nasl.core.Boolean;
            movementX: nasl.core.Integer;
            movementY: nasl.core.Integer;
            offsetX: nasl.core.Integer;
            offsetY: nasl.core.Integer;
            pageX: nasl.core.Integer;
            pageY: nasl.core.Integer;
            screenX: nasl.core.Integer;
            screenY: nasl.core.Integer;
            which: nasl.core.Integer;
        }) => any;
        onDoubleClick: (event: {
            altKey: nasl.core.Boolean;
            button: nasl.core.Integer;
            clientX: nasl.core.Integer;
            clientY: nasl.core.Integer;
            ctrlKey: nasl.core.Boolean;
            metaKey: nasl.core.Boolean;
            movementX: nasl.core.Integer;
            movementY: nasl.core.Integer;
            offsetX: nasl.core.Integer;
            offsetY: nasl.core.Integer;
            pageX: nasl.core.Integer;
            pageY: nasl.core.Integer;
            screenX: nasl.core.Integer;
            screenY: nasl.core.Integer;
            which: nasl.core.Integer;
        }) => any;
        onContextMenu: (event: {
            altKey: nasl.core.Boolean;
            button: nasl.core.Integer;
            clientX: nasl.core.Integer;
            clientY: nasl.core.Integer;
            ctrlKey: nasl.core.Boolean;
            metaKey: nasl.core.Boolean;
            movementX: nasl.core.Integer;
            movementY: nasl.core.Integer;
            offsetX: nasl.core.Integer;
            offsetY: nasl.core.Integer;
            pageX: nasl.core.Integer;
            pageY: nasl.core.Integer;
            screenX: nasl.core.Integer;
            screenY: nasl.core.Integer;
            which: nasl.core.Integer;
        }) => any;
        onMouseDown: (event: {
            altKey: nasl.core.Boolean;
            button: nasl.core.Integer;
            clientX: nasl.core.Integer;
            clientY: nasl.core.Integer;
            ctrlKey: nasl.core.Boolean;
            metaKey: nasl.core.Boolean;
            movementX: nasl.core.Integer;
            movementY: nasl.core.Integer;
            offsetX: nasl.core.Integer;
            offsetY: nasl.core.Integer;
            pageX: nasl.core.Integer;
            pageY: nasl.core.Integer;
            screenX: nasl.core.Integer;
            screenY: nasl.core.Integer;
            which: nasl.core.Integer;
        }) => any;
        onMouseUp: (event: {
            altKey: nasl.core.Boolean;
            button: nasl.core.Integer;
            clientX: nasl.core.Integer;
            clientY: nasl.core.Integer;
            ctrlKey: nasl.core.Boolean;
            metaKey: nasl.core.Boolean;
            movementX: nasl.core.Integer;
            movementY: nasl.core.Integer;
            offsetX: nasl.core.Integer;
            offsetY: nasl.core.Integer;
            pageX: nasl.core.Integer;
            pageY: nasl.core.Integer;
            screenX: nasl.core.Integer;
            screenY: nasl.core.Integer;
            which: nasl.core.Integer;
        }) => any;
        onMouseEnter: (event: {
            altKey: nasl.core.Boolean;
            button: nasl.core.Integer;
            clientX: nasl.core.Integer;
            clientY: nasl.core.Integer;
            ctrlKey: nasl.core.Boolean;
            metaKey: nasl.core.Boolean;
            movementX: nasl.core.Integer;
            movementY: nasl.core.Integer;
            offsetX: nasl.core.Integer;
            offsetY: nasl.core.Integer;
            pageX: nasl.core.Integer;
            pageY: nasl.core.Integer;
            screenX: nasl.core.Integer;
            screenY: nasl.core.Integer;
            which: nasl.core.Integer;
        }) => any;
        onMouseLeave: (event: {
            altKey: nasl.core.Boolean;
            button: nasl.core.Integer;
            clientX: nasl.core.Integer;
            clientY: nasl.core.Integer;
            ctrlKey: nasl.core.Boolean;
            metaKey: nasl.core.Boolean;
            movementX: nasl.core.Integer;
            movementY: nasl.core.Integer;
            offsetX: nasl.core.Integer;
            offsetY: nasl.core.Integer;
            pageX: nasl.core.Integer;
            pageY: nasl.core.Integer;
            screenX: nasl.core.Integer;
            screenY: nasl.core.Integer;
            which: nasl.core.Integer;
        }) => any;
    }
}
declare namespace nasl.ui {
    class TextArea extends ViewComponent {
        focus(): void;
        blur(): void;
        constructor(options?: Partial<TextAreaOptions>);
    }
    class TextAreaOptions extends ViewComponentOptions {
        value: nasl.core.String;
        placeholder: nasl.core.String;
        maxlength: nasl.core.Integer;
        allowClear: nasl.core.Boolean;
        disabled: nasl.core.Boolean;
        onChange: (event: {
            value: nasl.core.String;
            oldValue: nasl.core.String;
        }) => any;
        onFocus: (event: {
            cancelBubble: nasl.core.Boolean;
            detail: nasl.core.String;
            layerX: nasl.core.Integer;
            layerY: nasl.core.Integer;
            pageX: nasl.core.Integer;
            pageY: nasl.core.Integer;
            which: nasl.core.Integer;
        }) => any;
        onBlur: (event: {
            cancelBubble: nasl.core.Boolean;
            detail: nasl.core.String;
            layerX: nasl.core.Integer;
            layerY: nasl.core.Integer;
            pageX: nasl.core.Integer;
            pageY: nasl.core.Integer;
            which: nasl.core.Integer;
        }) => any;
        onKeyDown: (event: {
            altKey: nasl.core.Boolean;
            code: nasl.core.String;
            ctrlKey: nasl.core.Boolean;
            isComposing: nasl.core.Boolean;
            key: nasl.core.String;
            metaKey: nasl.core.Boolean;
            repeat: nasl.core.Boolean;
            shiftKey: nasl.core.Boolean;
        }) => any;
        onKeyUp: (event: {
            altKey: nasl.core.Boolean;
            code: nasl.core.String;
            ctrlKey: nasl.core.Boolean;
            isComposing: nasl.core.Boolean;
            key: nasl.core.String;
            metaKey: nasl.core.Boolean;
            repeat: nasl.core.Boolean;
            shiftKey: nasl.core.Boolean;
        }) => any;
    }
}
declare namespace nasl.ui {
    class TimePicker extends ViewComponent {
        constructor(options?: Partial<TimePickerOptions>);
    }
    class TimePickerOptions extends ViewComponentOptions {
        placeholder: nasl.core.String;
        hourStep: nasl.core.Integer;
        open: nasl.core.Boolean;
        minuteStep: nasl.core.Integer;
        secondStep: nasl.core.Integer;
        value: nasl.core.Time;
        autoFocus: nasl.core.Boolean;
        showNow: nasl.core.Boolean;
        use12Hours: nasl.core.Boolean;
        allowClear: nasl.core.Boolean;
        disabled: nasl.core.Boolean;
        onChange: (event: {
            date: nasl.core.String;
            time: nasl.core.String;
        }) => any;
        onBlur: (event: {
            cancelBubble: nasl.core.Boolean;
            detail: nasl.core.String;
            layerX: nasl.core.Integer;
            layerY: nasl.core.Integer;
            pageX: nasl.core.Integer;
            pageY: nasl.core.Integer;
            which: nasl.core.Integer;
        }) => any;
    }
}
declare namespace nasl.ui {
    class TimeRangePicker extends ViewComponent {
        constructor(options?: Partial<TimePickerOptions>);
    }
    class TimeRangePickerOptions extends ViewComponentOptions {
        value: Array<nasl.core.Time>;
        hourStep: nasl.core.Integer;
        minuteStep: nasl.core.Integer;
        secondStep: nasl.core.Integer;
        autoFocus: nasl.core.Boolean;
        use12Hours: nasl.core.Boolean;
        allowClear: nasl.core.Boolean;
        order: nasl.core.Boolean;
        disabled: nasl.core.Boolean;
        open: nasl.core.Boolean;
        onChange: (event: {
            date: nasl.core.String;
            time: nasl.core.String;
        }) => any;
        onBlur: (event: {
            cancelBubble: nasl.core.Boolean;
            detail: nasl.core.String;
            layerX: nasl.core.Integer;
            layerY: nasl.core.Integer;
            pageX: nasl.core.Integer;
            pageY: nasl.core.Integer;
            which: nasl.core.Integer;
        }) => any;
    }
}
declare namespace nasl.ui {
    class Transfer<T, V> extends ViewComponent {
        constructor(options?: Partial<TransferOptions<T, V>>);
    }
    class TransferOptions<T, V> extends ViewComponentOptions {
        private matchMethod;
        private pagination;
        source: nasl.collection.List<T>;
        target: nasl.collection.List<T>;
        textField: (item: T) => any;
        valueField: (item: T) => V;
        showSearch: nasl.core.Boolean;
        showSelectAll: nasl.core.Boolean;
        sourceTitle: nasl.core.String;
        targetTitle: nasl.core.String;
        disabled: nasl.core.Boolean;
        onChange: (event: {
            targetKeys: nasl.collection.List<T>;
            direction: nasl.collection.List<T>;
            moveKeys: nasl.collection.List<T>;
        }) => any;
        slotDefault: () => Array<ViewComponent>;
        slotRender: (current: Current<T>) => Array<ViewComponent>;
    }
}
declare namespace nasl.ui {
    class Tree<T, V, M extends nasl.core.Boolean> extends ViewComponent {
        data: TreeOptions<T, V, M>['dataSource'];
        reload(): void;
        constructor(options?: Partial<TreeOptions<T, V, M>>);
    }
    class TreeOptions<T, V, M extends nasl.core.Boolean> extends ViewComponentOptions {
        dataSource: nasl.collection.List<T> | {
            list: nasl.collection.List<T>;
            total: nasl.core.Integer;
        };
        dataSchema: T;
        textField: any;
        valueField: any;
        childrenField: any;
        parentField: any;
        checkStrictly: nasl.core.Boolean;
        checkable: nasl.core.Boolean;
        disabled: nasl.core.Boolean;
        onCheck: (event: {
            value: V;
            oldValue: V;
            node: T;
            oldNode: T;
        }) => any;
        onSelect: (value: V, event: {
            selected: V;
            selectedNodes: V;
            node: T;
            event: any;
        }) => any;
        onExpand: (event: {
            expanded: nasl.core.Boolean;
            node: T;
        }) => any;
        onLoad: (event: any) => any;
        slotDefault: () => Array<TreeNode<T, V>>;
    }
    class TreeNode<T, V> extends ViewComponent {
        constructor(options?: Partial<TreeNodeOptions<T, V>>);
    }
    class TreeNodeOptions<T, V> extends ViewComponentOptions {
        private node;
        key: any;
        disabled: nasl.core.Boolean;
        slotDefault: (current: Current<T>) => Array<TreeNode<T, V>>;
        slotTitle: () => Array<ViewComponent>;
    }
}
declare namespace nasl.ui {
    class TreeSelect<T, V, M extends nasl.core.Boolean> extends ViewComponent {
        reload(): void;
        constructor(options?: Partial<TreeSelectOptions<T, V, M>>);
    }
    class TreeSelectOptions<T, V, M extends nasl.core.Boolean> extends ViewComponentOptions {
        dataSource: nasl.collection.List<T> | {
            list: nasl.collection.List<T>;
            total: nasl.core.Integer;
        };
        dataSchema: T;
        textField: (item: T) => any;
        valueField: (item: T) => V;
        childrenField: (item: T) => any;
        parentField: (item: T) => any;
        value: V;
        treeCheckable: nasl.core.Boolean;
        placeholder: nasl.core.String;
        treeCheckStrictly: nasl.core.Boolean;
        disabled: nasl.core.Boolean;
        onChange: (event: {
            value: V;
            oldValue: V;
            node: T;
            oldNode: T;
        }) => any;
        onSelect: (event: {
            value: V;
            oldValue: V;
            node: T;
            oldNode: T;
        }) => any;
    }
}
declare namespace nasl.ui {
    class Upload extends ViewComponent {
        constructor(options?: Partial<UploadOptions>);
    }
    class UploadOptions extends ViewComponentOptions {
        private dataType;
        private pastable;
        fileList: nasl.collection.List<nasl.core.String>;
        action: nasl.core.String;
        name: nasl.core.String;
        accept: nasl.core.String;
        withCredentials: nasl.core.Boolean;
        data: object;
        maxCount: nasl.core.Decimal;
        listType: 'text' | 'picture' | 'picture-card' | 'picture-circle';
        url: nasl.core.String;
        private iconMap;
        headers: Object;
        multiple: nasl.core.Boolean;
        private autoUpload;
        disabled: nasl.core.Boolean;
        onChange: (event: {
            file: nasl.core.String;
        }) => any;
        onRemove: (event: {
            value: {
                url: nasl.core.String;
                name: nasl.core.String;
            };
            item: File;
            index: nasl.core.Integer;
        }) => any;
        slotDefault: () => Array<ViewComponent>;
        slotFileList: () => Array<ViewComponent>;
        slotDragDescription: () => Array<ViewComponent>;
    }
}
declare namespace nasl.ui {
    class FormItem extends ViewComponent {
        constructor(options?: Partial<FormItemOptions>);
    }
    class FormItemOptions extends ViewComponentOptions {
        name: nasl.core.String;
        labelIsSlot: nasl.core.Boolean;
        labelText: nasl.core.String;
        private muted;
        private validatingProcess;
        span: nasl.core.Decimal;
        required: nasl.core.Boolean;
        tooltip: nasl.core.String;
        rules: nasl.core.String;
        slotDefault: () => Array<ViewComponent>;
        slotLabel: () => Array<ViewComponent>;
        slotDescription: () => Array<ViewComponent>;
        slotExtra: () => Array<ViewComponent>;
    }
}
